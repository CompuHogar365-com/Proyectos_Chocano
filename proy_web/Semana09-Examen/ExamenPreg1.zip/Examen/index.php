<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>INVERSIONES</title>
</head>
<body>
    <h1>INVERSION EMPRENDE SAC</h1>
    <h2>Montos:</h2>
    <form action="operacion.php" method="post">
    <label for="inversor1">Socio N°1:</label>
    <input type="text" name="v_inversor1" id="inversor1">
    <br><br>
    <label for="inversor2">Socio N°2:</label>
    <input type="text" name="v_inversor2" id="inversor2">
    <br><br>
    <label for="inversor3">Socio N°3:</label>
    <input type="text" name="v_inversor3" id="inversor3">
    <br><br>
    <input type="submit" value="Calcular">
    </form>
    
</body>
</html>